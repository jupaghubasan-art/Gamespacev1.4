package com.sanju.systemx.shizuku

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.concurrent.atomic.AtomicBoolean

enum class ShizukuState { CONNECTED, DISCONNECTED, PERMISSION_REQUIRED, UNSUPPORTED }

/** Structured result of one privileged command. Nothing is reported as success unless the exit code says so. */
class CommandResult(
    val success: Boolean,
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val durationMs: Long,
    val capability: String,
    val errorReason: String
) {
    val code: Int get() = exitCode
    val ok: Boolean get() = success
    /** stdout plus stderr, trimmed. */
    val out: String get() = if (stderr.isEmpty()) stdout.trim() else (stdout + "\n" + stderr).trim()
}

typealias ShellResult = CommandResult

/**
 * The single privileged execution layer. Every Shizuku shell call in the app goes through run()/sh().
 * Handles binder detection, permission, binder death/reconnect listeners, timeouts, stdout/stderr/exit code.
 */
object ShizukuBridge {
    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4242

    /** Set only when this Shizuku build truly lacks the shell API. Cleared again whenever the binder reconnects. */
    @Volatile private var noNewProcess = false
    @Volatile private var listening = false

    /** Called with "BINDER", "DEAD" or "PERMISSION" when Shizuku changes. Set by the Engine. */
    @Volatile var onChange: ((String) -> Unit)? = null

    private val receivedL = Shizuku.OnBinderReceivedListener {
        noNewProcess = false
        onChange?.invoke("BINDER")
    }
    private val deadL = Shizuku.OnBinderDeadListener { onChange?.invoke("DEAD") }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> onChange?.invoke("PERMISSION") }

    /** Registers the lifecycle listeners once. Safe to call repeatedly. */
    fun start() {
        if (listening) return
        listening = true
        try {
            Shizuku.addBinderReceivedListenerSticky(receivedL)
            Shizuku.addBinderDeadListener(deadL)
            Shizuku.addRequestPermissionResultListener(permL)
        } catch (t: Throwable) {
            listening = false
        }
    }

    fun isInstalled(ctx: Context): Boolean =
        try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (t: Throwable) { false }

    fun state(): ShizukuState {
        if (noNewProcess) return ShizukuState.UNSUPPORTED
        return try {
            if (Shizuku.isPreV11()) ShizukuState.UNSUPPORTED
            else if (!Shizuku.pingBinder()) ShizukuState.DISCONNECTED
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) ShizukuState.CONNECTED
            else ShizukuState.PERMISSION_REQUIRED
        } catch (t: Throwable) {
            ShizukuState.DISCONNECTED
        }
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (t: Throwable) { }
    }

    private val newProcessMethod by lazy {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        m
    }

    /** Runs a command with shell privileges. Never throws. */
    fun run(cmd: Array<String>, capability: String = "", timeoutMs: Long = 5000L): CommandResult {
        val t0 = System.currentTimeMillis()
        fun fail(code: Int, why: String): CommandResult =
            CommandResult(false, code, "", why, System.currentTimeMillis() - t0, capability, why)
        val st = state()
        if (st != ShizukuState.CONNECTED) return fail(-2, "SHIZUKU REQUIRED ($st)")
        var proc: Process? = null
        try {
            val p = newProcessMethod.invoke(null, cmd, null, null) as Process
            proc = p
            val timedOut = AtomicBoolean(false)
            val killer = Thread {
                try { Thread.sleep(timeoutMs); timedOut.set(true); p.destroy() } catch (e: InterruptedException) { }
            }
            killer.isDaemon = true
            killer.start()
            val err = StringBuilder()
            val errT = Thread {
                try { err.append(p.errorStream.bufferedReader().readText()) } catch (e: Throwable) { }
            }
            errT.isDaemon = true
            errT.start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            errT.join(500)
            killer.interrupt()
            val to = timedOut.get()
            return CommandResult(
                code == 0 && !to, code, out.trim(), err.toString().trim(),
                System.currentTimeMillis() - t0, capability,
                if (to) "TIMEOUT" else if (code != 0) "EXIT $code" else ""
            )
        } catch (e: NoSuchMethodException) {
            noNewProcess = true
            return fail(-3, "UNSUPPORTED: this Shizuku version has no shell API")
        } catch (t: Throwable) {
            return fail(-1, "SHELL ERROR: " + (t.cause?.message ?: t.message ?: t.javaClass.simpleName))
        } finally {
            try { proc?.destroy() } catch (t: Throwable) { }
        }
    }

    fun exec(cmd: Array<String>, timeoutMs: Long = 5000L): CommandResult = run(cmd, "", timeoutMs)

    fun sh(script: String, timeoutMs: Long = 5000L, capability: String = ""): CommandResult =
        run(arrayOf("sh", "-c", script), capability, timeoutMs)

    /** Reads an Android setting. Returns "null" when unset or unreadable. */
    fun setting(ns: String, key: String): String =
        sh("settings get $ns $key 2>/dev/null", 3000L, "SETTINGS").stdout.trim().ifEmpty { "null" }
}
