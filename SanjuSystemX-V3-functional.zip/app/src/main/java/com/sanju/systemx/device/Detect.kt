package com.sanju.systemx.device

import android.content.Context
import android.os.Build
import com.sanju.systemx.caps.Cap
import com.sanju.systemx.caps.Capability
import com.sanju.systemx.caps.Caps
import com.sanju.systemx.game.ProfileStore
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.shizuku.ShizukuBridge

class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val sdk: Int,
    val board: String,
    val soc: String,
    val gpuRenderer: String,
    val gpuVendor: String,
    val cpuCores: Int,
    val clusters: List<String>,
    val gpu: Sampler.GpuInfo?
) {
    val cpuLine: String get() = cpuCores.toString() + " cores" + (if (clusters.isEmpty()) "" else " \u00B7 " + clusters.joinToString(" + "))
    val socLine: String get() = listOf(soc, board).filter { it.isNotBlank() }.distinct().joinToString(" / ").ifEmpty { "UNKNOWN" }
}

/** Detects what this device actually exposes and fills the capability registry. Nothing is assumed per-vendor. */
object Detect {
    private val SCRIPT = """
echo "MFR=§(getprop ro.product.manufacturer)"
echo "BOARD=§(getprop ro.board.platform)"
echo "SOC=§(getprop ro.soc.model)"
echo "GLES=§(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 GLES)"
echo "CPUS=§(ls -d /sys/devices/system/cpu/cpu[0-9]* 2>/dev/null | wc -l)"
for p in /sys/devices/system/cpu/cpufreq/policy*; do [ -d "§p" ] || continue; echo "POLICY=§(basename §p)|§(cat §p/related_cpus 2>/dev/null)|§(cat §p/cpuinfo_max_freq 2>/dev/null)"; done
echo "PWRSET=§(cmd power help 2>/dev/null | grep -c set-fixed-performance-mode-enabled)"
echo "PWRGET=§(cmd power help 2>/dev/null | grep -c get-fixed-performance-mode-enabled)"
echo "SFSAT=§(service call SurfaceFlinger 1022 f 1.0 2>&1 | head -n 1)"
echo "CMODE=§(dumpsys color_display 2>/dev/null | grep -i -m1 'color mode')"
echo "TOUCH=§(settings get secure long_press_timeout 2>/dev/null)"
echo "DNSM=§(settings get global private_dns_mode 2>/dev/null)"
echo "THERM=§(dumpsys thermalservice 2>/dev/null | grep -m1 -i 'Thermal Status')"
echo "GAME=§(cmd game list-modes PKGX 2>&1 | head -n 3 | tr '\n' ' ')"
""".replace('§', '$')

    @Volatile var info: DeviceInfo? = null
    @Volatile var sfColorOk = false
    @Volatile var colorModeOk = false

    fun run(ctx: Context): DeviceInfo? {
        val r = ShizukuBridge.sh(SCRIPT.replace("PKGX", ProfileStore.MLBB), 12000L, "DETECT")
        if (!r.ok && r.stdout.isEmpty()) return null
        val kv = HashMap<String, String>()
        val clusters = ArrayList<String>()
        for (l in r.stdout.lines()) {
            val i = l.indexOf('=')
            if (i <= 0) continue
            val k = l.substring(0, i)
            val v = l.substring(i + 1).trim()
            if (k == "POLICY") {
                val p = v.split('|')
                if (p.size >= 3) {
                    val mhz = (p[2].trim().toLongOrNull() ?: 0L) / 1000L
                    clusters.add("cpu" + p[1].trim().replace(' ', ',') + (if (mhz > 0) " @" + mhz + "MHz" else ""))
                }
            } else kv[k] = v
        }
        val gles = kv["GLES"] ?: ""
        val gpuVendor = when {
            gles.contains("Adreno", true) || gles.contains("Qualcomm", true) -> "Qualcomm Adreno"
            gles.contains("Mali", true) || gles.contains("ARM", true) -> "ARM Mali"
            gles.contains("PowerVR", true) || gles.contains("Imagination", true) -> "PowerVR"
            gles.contains("Xclipse", true) -> "Samsung Xclipse"
            gles.isBlank() -> "UNKNOWN"
            else -> gles.substringAfter("GLES:").trim().take(30)
        }
        val gpu = Sampler.probeGpu()
        val info = DeviceInfo(
            kv["MFR"] ?: Build.MANUFACTURER, Build.MODEL, Build.VERSION.SDK_INT,
            kv["BOARD"] ?: "", kv["SOC"] ?: "", gles.substringAfter("GLES:").trim(), gpuVendor,
            kv["CPUS"]?.toIntOrNull() ?: Runtime.getRuntime().availableProcessors(), clusters, gpu
        )
        this.info = info
        fill(ctx, kv, gpu)
        return info
    }

    private fun fill(ctx: Context, kv: Map<String, String>, gpu: Sampler.GpuInfo?) {
        Caps.clear()
        val max = DisplayCtl.maxRate(ctx)
        Caps.put(Capability(Cap.DISPLAY_HIGH_REFRESH, max >= 90, max >= 90, false,
            if (max >= 90) "Panel reports up to $max Hz at the current resolution" else "Panel reports only " + (if (max > 0) "$max Hz" else "unknown rates"),
            "Settings min/peak_refresh_rate"))
        val game = kv["GAME"] ?: ""
        val gameOk = Build.VERSION.SDK_INT >= 31 && game.isNotBlank() &&
            !game.contains("unknown command", true) && !game.contains("exception", true) && !game.contains("error", true)
        Caps.put(Capability(Cap.GAME_MODE, gameOk, gameOk, false,
            if (gameOk) "cmd game answers" else if (Build.VERSION.SDK_INT < 31) "Needs Android 12+" else "cmd game not available",
            "cmd game"))
        Caps.put(Capability(Cap.GPU_MONITOR, gpu != null, false, false,
            if (gpu != null) "GPU frequency readable" else "No readable GPU devfreq interface", "devfreq / kgsl"))
        val gpuW = gpu != null && gpu.writableMin && gpu.avail.isNotEmpty()
        Caps.put(Capability(Cap.GPU_PERFORMANCE, gpuW, gpuW, false,
            if (gpuW) gpu!!.avail.size.toString() + " frequency steps, min_freq writable"
            else if (gpu == null) "No GPU devfreq interface" else "Interface is read-only for the shell user", "devfreq min_freq"))
        Caps.put(Capability(Cap.CPU_MONITOR, true, false, false, "cpufreq and /proc/stat readable", "sysfs"))
        val pwr = (kv["PWRSET"]?.trim()?.toIntOrNull() ?: 0) > 0
        Caps.put(Capability(Cap.CPU_PERFORMANCE, pwr, pwr, false,
            if (pwr) "Android fixed-performance power mode exists (effect depends on the device HAL)" else "No supported CPU performance command",
            "cmd power set-fixed-performance-mode-enabled"))
        val th = (kv["THERM"] ?: "").isNotBlank()
        Caps.put(Capability(Cap.THERMAL, true, false, false,
            if (th) "Android thermal status + zones + battery" else "Zones + battery only", "thermalservice / sysfs"))
        val touch = (kv["TOUCH"] ?: "").trim().toIntOrNull() != null
        Caps.put(Capability(Cap.TOUCH_RESPONSE, touch, touch, false,
            if (touch) "Touch-and-hold delay is adjustable. Android has no touch-latency control" else "Setting not readable",
            "secure long_press_timeout"))
        val sf = (kv["SFSAT"] ?: "").let { it.contains("Parcel(") && !it.contains("rror", true) }
        val cm = (kv["CMODE"] ?: "").isNotBlank()
        sfColorOk = sf
        colorModeOk = cm
        Caps.put(Capability(Cap.DISPLAY_COLOR, sf || cm, sf || cm, false,
            if (sf && cm) "SurfaceFlinger colour transform + colour mode" else if (sf) "SurfaceFlinger colour transform" else if (cm) "Colour mode setting" else "No display colour control exposed",
            if (sf) "SurfaceFlinger 1022/1015" else "secure display_color_mode"))
        val dns = (kv["DNSM"] ?: "").isNotBlank()
        Caps.put(Capability(Cap.DNS, dns, dns, false,
            if (dns) "Private DNS settings are readable" else "Private DNS setting not readable", "global private_dns_*"))
    }

    /** True when SurfaceFlinger colour transform is available (separate from colour mode). */
    fun hasSfColor(): Boolean = Caps.get(Cap.DISPLAY_COLOR)?.backend?.startsWith("SurfaceFlinger") == true
}
