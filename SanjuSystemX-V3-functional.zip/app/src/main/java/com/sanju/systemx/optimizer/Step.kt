package com.sanju.systemx.optimizer

/** Honest life-cycle of every optimisation step. VERIFIED is only used when a read-back proved the change. */
enum class St(val label: String) {
    NOT_REQUESTED("NOT REQUESTED"),
    REQUESTED("REQUESTED"),
    APPLIED("APPLIED"),
    VERIFIED("VERIFIED"),
    FAILED("FAILED"),
    UNSUPPORTED("UNSUPPORTED")
}

class Step(val st: St, val detail: String = "") {
    fun text(): String = if (detail.isEmpty()) st.label else st.label + " \u00B7 " + detail
    companion object { val NONE = Step(St.NOT_REQUESTED) }
}
