package com.sanju.systemx.optimizer

import android.content.Context
import com.sanju.systemx.resolution.DisplayCtl

/**
 * SANJU AUTO decision. The panel's real capability decides the target:
 * 60 Hz -> about 30 FPS, 90 Hz -> about 60 FPS, 120 Hz or more -> about 90 FPS.
 * The target is only a goal. The Monitor shows what the game really renders.
 */
object AutoPlan {
    class Plan(val maxHz: Int, val reqHz: Int, val targetFps: Int, val note: String)

    fun targetFor(maxHz: Int): Int = if (maxHz >= 120) 90 else if (maxHz >= 90) 60 else 30

    /** perfMode: 1 BALANCED, 2 PERFORMANCE. */
    fun compute(ctx: Context, perfMode: Int): Plan {
        val rates = DisplayCtl.ratesAtCurrentRes(ctx)
        if (rates.isEmpty()) return Plan(-1, -1, 0, "Display modes are unreadable")
        val max = rates.last()
        val target = targetFor(max)
        val req = if (perfMode >= 2) max else (rates.firstOrNull { it >= target } ?: max)
        return Plan(max, req, target, "Panel max $max Hz -> request $req Hz, game target about $target FPS")
    }
}
