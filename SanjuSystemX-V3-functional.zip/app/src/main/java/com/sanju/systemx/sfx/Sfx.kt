package com.sanju.systemx.sfx

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.ui.Pal
import java.lang.ref.WeakReference

/**
 * All sounds are original, synthesized, and stored in res/raw. They are looked up by name, so a missing file
 * just stays silent. cine = part of the intro cinematic: plays on cue, layered, never dropped by the anti-overlap rule.
 */
enum class Sfx(
    val file: String, val cooldownMs: Long, val priority: Int, val durationMs: Long,
    val haptic: Boolean = false, val reject: Boolean = false, val cine: Boolean = false
) {
    CLICK("sfx_click", 60, 1, 40),
    TOGGLE_ON("sfx_toggle_on", 90, 1, 160),
    TOGGLE_OFF("sfx_toggle_off", 90, 1, 160),
    SUCCESS("sfx_success", 250, 2, 350),
    GAME_DETECTED("sfx_game_detected", 800, 3, 260, haptic = true),
    OPTIMIZE_DONE("sfx_optimize_done", 400, 3, 480, haptic = true),
    GAME_LAUNCH("sfx_game_launch", 800, 4, 280),
    BOOST_ON("sfx_boost_on", 600, 4, 410, haptic = true),
    WARNING("sfx_warning", 400, 5, 310, haptic = true, reject = true),
    INTRO_OPEN("sfx_intro_open", 0, 0, 1000, cine = true),
    EYE("sfx_eye", 0, 0, 750, haptic = true, cine = true),
    INTENSIFY("sfx_intensify", 0, 0, 1000, cine = true),
    PANEL("sfx_panel", 0, 0, 170, cine = true),
    READY("sfx_ready", 0, 0, 1080, haptic = true, cine = true)
}

/** SoundPool based: requests no audio focus and never changes any volume, so a game's audio is untouched. */
class SfxPlayer(context: Context, private val prefs: Prefs) {
    private val appCtx = context.applicationContext
    private val lock = Any()
    private var pool: SoundPool? = null
    private val ids = HashMap<Sfx, Int>()
    private val loaded = HashSet<Int>()
    private val lastPlayed = HashMap<Sfx, Long>()
    private var hapticView: WeakReference<View>? = null
    private var busyUntil = 0L
    private var busyPriority = 0
    private var lastStream = 0
    private val pending = ArrayList<Triple<Sfx, Float, Long>>()
    @Volatile private var released = false

    init {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val p = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
            p.setOnLoadCompleteListener { _, sampleId, status ->
                if (status == 0) {
                    val again = ArrayList<Pair<Sfx, Float>>()
                    synchronized(lock) {
                        loaded.add(sampleId)
                        val now = SystemClock.uptimeMillis()
                        val it = pending.iterator()
                        while (it.hasNext()) {
                            val t = it.next()
                            if (ids[t.first] == sampleId) {
                                it.remove()
                                if (now - t.third < 1500L) again.add(Pair(t.first, t.second))
                            }
                        }
                    }
                    for (a in again) play(a.first, a.second)
                }
            }
            pool = p
            for (s in Sfx.values()) {
                val res = try { appCtx.resources.getIdentifier(s.file, "raw", appCtx.packageName) } catch (e: Throwable) { 0 }
                if (res == 0) continue
                val id = try { p.load(appCtx, res, 1) } catch (e: Throwable) { 0 }
                if (id != 0) ids[s] = id
            }
        } catch (e: Throwable) {
            pool = null
        }
    }

    fun attachHaptics(v: View) { hapticView = WeakReference(v) }

    fun play(s: Sfx, rate: Float = 1f) {
        if (released) return
        val now = SystemClock.uptimeMillis()
        if (!s.cine) {
            synchronized(lock) { if (now - (lastPlayed[s] ?: 0L) < s.cooldownMs) return }
        }
        if (Pal.haptic && s.haptic) buzz(s)
        if (!prefs.getB("sfx_on", true)) return
        val p = pool ?: return
        val id = ids[s] ?: return
        val vol = prefs.getF("sfx_vol", 0.7f).coerceIn(0f, 1f)
        if (vol <= 0f) return
        synchronized(lock) {
            if (id !in loaded) { pending.add(Triple(s, rate, now)); return }
            if (!s.cine && now < busyUntil) {
                if (s.priority < busyPriority) return
                try { p.stop(lastStream) } catch (e: Throwable) { }
            }
            val stream = try { p.play(id, vol, vol, s.priority, 0, rate.coerceIn(0.5f, 2f)) } catch (e: Throwable) { 0 }
            if (stream != 0 && !s.cine) {
                lastStream = stream
                lastPlayed[s] = now
                busyUntil = now + s.durationMs
                busyPriority = s.priority
            }
        }
    }

    /** Follows the system touch-feedback setting; it cannot force a vibration. */
    private fun buzz(s: Sfx) {
        val v = hapticView?.get() ?: return
        try {
            val c = if (Build.VERSION.SDK_INT >= 30) {
                if (s.reject) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.CONFIRM
            } else HapticFeedbackConstants.LONG_PRESS
            v.performHapticFeedback(c)
        } catch (e: Throwable) { }
    }

    fun release() {
        if (released) return
        released = true
        synchronized(lock) {
            try { pool?.release() } catch (e: Throwable) { }
            pool = null
            ids.clear(); loaded.clear(); pending.clear()
        }
        hapticView = null
    }
}

object SfxHub {
    @Volatile private var player: SfxPlayer? = null
    fun bind(p: SfxPlayer) { player = p }
    fun unbind(p: SfxPlayer) { if (player === p) player = null }
    fun play(s: Sfx, rate: Float = 1f) { player?.play(s, rate) }
}
