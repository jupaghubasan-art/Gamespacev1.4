package com.sanju.systemx.game

import com.sanju.systemx.settings.Prefs

/** One game's settings. perfMode: 0 OFF, 1 BALANCED, 2 PERFORMANCE. effect: index into Effects. dns: index into DNS. touch: 0 FAST, 1 DEFAULT, 2 SLOW. */
class GameProfile(
    val pkg: String,
    val name: String,
    var perfMode: Int = 2,
    var effect: Int = 4,
    var dns: Int = 0,
    var touch: Int = 1,
    var autoOptimize: Boolean = true,
    var restoreOnExit: Boolean = true
)

/** Holds all game profiles. Mobile Legends is built in; others are added with add() and persisted in Prefs. */
object ProfileStore {
    const val MLBB = "com.mobile.legends"
    private const val KEY = "game_profiles"
    private val list = ArrayList<GameProfile>()
    @Volatile var selectedPkg: String = MLBB

    fun load(prefs: Prefs) {
        synchronized(list) {
            list.clear()
            for (l in prefs.getS(KEY, "").lines()) {
                val p = l.split('|')
                if (p.size < 8 || p[0].isBlank()) continue
                list.add(GameProfile(p[0], p[1], p[2].toIntOrNull() ?: 2, p[3].toIntOrNull() ?: 4,
                    p[4].toIntOrNull() ?: 0, p[5].toIntOrNull() ?: 1, p[6] == "1", p[7] == "1"))
            }
            if (list.none { it.pkg == MLBB }) list.add(0, GameProfile(MLBB, "Mobile Legends"))
            selectedPkg = prefs.getS("selected_game", MLBB)
            if (list.none { it.pkg == selectedPkg }) selectedPkg = MLBB
        }
    }

    fun save(prefs: Prefs) {
        val s = synchronized(list) {
            list.joinToString("\n") {
                it.pkg + "|" + it.name.replace('|', ' ') + "|" + it.perfMode + "|" + it.effect + "|" + it.dns + "|" +
                    it.touch + "|" + (if (it.autoOptimize) "1" else "0") + "|" + (if (it.restoreOnExit) "1" else "0")
            }
        }
        prefs.setS(KEY, s)
        prefs.setS("selected_game", selectedPkg)
    }

    fun all(): List<GameProfile> = synchronized(list) { ArrayList(list) }
    fun find(pkg: String): GameProfile? = synchronized(list) { list.firstOrNull { it.pkg == pkg } }
    fun selected(): GameProfile = find(selectedPkg) ?: all().first()

    fun add(prefs: Prefs, pkg: String, name: String): GameProfile {
        val ex = find(pkg)
        if (ex != null) { selectedPkg = pkg; save(prefs); return ex }
        val g = GameProfile(pkg, name)
        synchronized(list) { list.add(g) }
        selectedPkg = pkg
        save(prefs)
        return g
    }

    /** Returns the profile whose package appears in the foreground-activity text, or null. */
    fun matchForeground(txt: String): GameProfile? = all().firstOrNull { txt.contains(it.pkg) }

    fun cycleSelected(prefs: Prefs) {
        val a = all()
        val i = a.indexOfFirst { it.pkg == selectedPkg }
        selectedPkg = a[(i + 1) % a.size].pkg
        save(prefs)
    }
}
