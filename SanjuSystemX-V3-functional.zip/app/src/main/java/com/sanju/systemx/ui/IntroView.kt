package com.sanju.systemx.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import com.sanju.systemx.R
import com.sanju.systemx.sfx.Sfx
import com.sanju.systemx.sfx.SfxHub

/**
 * 5 second cinematic. Drawn on a Canvas, driven by one animator clock. Sound cues fire from the same clock,
 * so picture and sound stay in sync. System initialisation is NOT waiting for this (Engine starts in onCreate).
 * Tap to skip.
 */
class IntroView(ctx: Context, private val onDone: () -> Unit) : View(ctx) {
    private val eye: Bitmap? = try { BitmapFactory.decodeResource(resources, R.drawable.mangekyo) } catch (t: Throwable) { null }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val almond = Path()
    private val rect = RectF()
    private var t = 0f
    private var anim: ValueAnimator? = null
    private var finished = false
    private val cueAt = floatArrayOf(0f, 0.85f, 2.0f, 3.0f, 3.25f, 3.5f, 3.75f, 4.0f)
    private val fired = BooleanArray(cueAt.size)
    private val labels = arrayOf("FPS", "Hz", "CPU", "GPU")

    init {
        txt.typeface = HUD_FONT
        txt.textAlign = Paint.Align.CENTER
        setBackgroundColor(Color.BLACK)
    }

    fun start() {
        val a = ValueAnimator.ofFloat(0f, 5f)
        a.duration = 5000L
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            fireCues()
            invalidate()
            if (t >= 5f) finish()
        }
        anim = a
        a.start()
    }

    private fun fireCues() {
        for (i in cueAt.indices) {
            if (!fired[i] && t >= cueAt[i]) {
                fired[i] = true
                when (i) {
                    0 -> SfxHub.play(Sfx.INTRO_OPEN)
                    1 -> SfxHub.play(Sfx.EYE)
                    2 -> SfxHub.play(Sfx.INTENSIFY)
                    3 -> SfxHub.play(Sfx.PANEL, 1.0f)
                    4 -> SfxHub.play(Sfx.PANEL, 1.12f)
                    5 -> SfxHub.play(Sfx.PANEL, 1.26f)
                    6 -> SfxHub.play(Sfx.PANEL, 1.5f)
                    7 -> SfxHub.play(Sfx.READY)
                }
            }
        }
    }

    private fun finish() {
        if (finished) return
        finished = true
        anim?.cancel()
        onDone()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) finish()
        return true
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun ease(x: Float): Float { val v = x.coerceIn(0f, 1f); return v * v * (3f - 2f * v) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val md = minOf(w, h)
        var cx = w / 2f
        var cy = h / 2f
        c.drawColor(Color.BLACK)

        // ambient red glow: 0-1s fades in, stronger later, final pulse at 4.0s
        var glow = 0.25f * ease(t / 1f)
        if (t >= 2f) glow += 0.25f * ease(t - 2f)
        if (t >= 4f) glow += 0.35f * (1f - ease((t - 4f) / 0.6f))
        p.shader = RadialGradient(cx, cy, md * 0.9f, Color.argb((glow * 255).toInt().coerceIn(0, 255), 229, 23, 63), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // final: eye moves up and shrinks to make room for the branding
        val settle = ease((t - 4f) / 0.6f)
        cy -= h * 0.12f * settle
        val scaleFinal = 1f - 0.3f * settle

        // eye: 1.0-1.6s lids open, 2-3s intensifies
        if (t >= 1f) {
            val open = ease((t - 1f) / 0.6f)
            val grow = 1f + 0.25f * ease(t - 2f)
            val a = md * 0.55f * grow * scaleFinal
            val b = md * 0.30f * grow * scaleFinal * (0.25f + 0.75f * open)
            almond.reset()
            almond.moveTo(cx - a, cy)
            almond.quadTo(cx, cy - b * 2f, cx + a, cy)
            almond.quadTo(cx, cy + b * 2f, cx - a, cy)
            almond.close()
            c.save()
            c.clipPath(almond)
            p.color = Color.parseColor("#120004")
            c.drawRect(0f, 0f, w, h, p)
            val rot = when {
                t < 2f -> (t - 1f) * 90f
                t < 3f -> 90f + (t - 2f) * 360f
                t < 4f -> 450f + (t - 3f) * 360f * (1f - ease(t - 3f))
                else -> 450f + 360f * 0.0f
            }
            val r = md * 0.28f * grow * scaleFinal * ease((t - 1.1f) / 0.5f)
            if (eye != null && r > 1f) {
                c.save()
                c.translate(cx, cy)
                c.rotate(rot)
                rect.set(-r, -r, r, r)
                c.drawBitmap(eye, null, rect, null)
                c.restore()
            }
            c.restore()
            p.style = Paint.Style.STROKE
            p.strokeWidth = md * 0.008f
            p.color = Pal.RED
            c.drawPath(almond, p)
            p.style = Paint.Style.FILL
            // red activation pulses at 1.0s and 2.0s
            for (start in floatArrayOf(1.0f, 2.0f)) {
                val k = (t - start) / 0.8f
                if (k in 0f..1f) {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = md * 0.01f
                    p.color = Color.argb(((1f - k) * 200).toInt(), 229, 23, 63)
                    c.drawCircle(cx, cy, md * 0.2f + md * 0.5f * k, p)
                    p.style = Paint.Style.FILL
                }
            }
        }

        // HUD corner brackets 2-3s
        if (t >= 2f) {
            val k = ease(t - 2f)
            val m = md * 0.06f
            val len = md * 0.14f * k
            p.color = Pal.RED
            p.strokeWidth = md * 0.006f
            p.style = Paint.Style.STROKE
            c.drawLine(m, m, m + len, m, p); c.drawLine(m, m, m, m + len, p)
            c.drawLine(w - m, m, w - m - len, m, p); c.drawLine(w - m, m, w - m, m + len, p)
            c.drawLine(m, h - m, m + len, h - m, p); c.drawLine(m, h - m, m, h - m - len, p)
            c.drawLine(w - m, h - m, w - m - len, h - m, p); c.drawLine(w - m, h - m, w - m, h - m - len, p)
            p.style = Paint.Style.FILL
        }

        // panels activate one by one 3.0-4.0s
        if (t >= 3f) {
            val pw = md * 0.32f
            val ph = md * 0.13f
            val gap = md * 0.04f
            val total = 4 * pw + 3 * gap
            val x0 = (w - total) / 2f
            val y0 = h - md * 0.17f
            for (i in 0 until 4) {
                val on = t >= 3f + 0.25f * i
                val x = x0 + i * (pw + gap)
                rect.set(x, y0, x + pw, y0 + ph)
                p.style = Paint.Style.FILL
                p.color = if (on) Color.argb(60, 229, 23, 63) else Color.argb(25, 255, 255, 255)
                c.drawRoundRect(rect, ph * 0.2f, ph * 0.2f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = md * 0.004f
                p.color = if (on) Pal.RED else Pal.PANEL2
                c.drawRoundRect(rect, ph * 0.2f, ph * 0.2f, p)
                p.style = Paint.Style.FILL
                txt.color = if (on) Color.WHITE else Pal.SUB
                txt.textSize = ph * 0.42f
                txt.letterSpacing = 0.1f
                c.drawText(labels[i], rect.centerX(), rect.centerY() + ph * 0.05f, txt)
                txt.textSize = ph * 0.2f
                txt.color = if (on) Pal.RED else Pal.SUB
                c.drawText(if (on) "ONLINE" else "STANDBY", rect.centerX(), rect.centerY() + ph * 0.35f, txt)
            }
        }

        // branding 4-5s
        if (t >= 4f) {
            val k = ease((t - 4.1f) / 0.5f)
            txt.color = Color.argb((k * 255).toInt().coerceIn(0, 255), 255, 255, 255)
            txt.textSize = md * 0.11f
            txt.letterSpacing = 0.25f - 0.1f * k
            c.drawText("SANJUSYSTEMX", w / 2f, h * 0.70f, txt)
            val k2 = ease((t - 4.4f) / 0.4f)
            txt.color = Color.argb((k2 * 255).toInt().coerceIn(0, 255), 229, 23, 63)
            txt.textSize = md * 0.05f
            txt.letterSpacing = 0.3f
            c.drawText("GAME SPACE READY", w / 2f, h * 0.70f + md * 0.08f, txt)
        }
    }
}
