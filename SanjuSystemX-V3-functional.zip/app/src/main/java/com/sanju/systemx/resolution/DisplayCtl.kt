package com.sanju.systemx.resolution

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display

/** Reads the real display state from Android. Nothing here is assumed or faked. */
object DisplayCtl {
    private fun disp(ctx: Context): Display? = try {
        (ctx.applicationContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
    } catch (t: Throwable) { null }

    /** Refresh rate of the active display mode in Hz, or -1 if unreadable. */
    fun current(ctx: Context): Float = try { disp(ctx)?.refreshRate ?: -1f } catch (t: Throwable) { -1f }

    /** Distinct refresh rates of every mode the panel reports, ascending. */
    fun rates(ctx: Context): List<Int> {
        val d = disp(ctx) ?: return emptyList()
        return try {
            d.supportedModes.map { Math.round(it.refreshRate) }.distinct().sorted()
        } catch (t: Throwable) { emptyList() }
    }

    /** Refresh rates available at the CURRENT resolution only (what the panel can really switch to without a resolution change). */
    fun ratesAtCurrentRes(ctx: Context): List<Int> {
        val d = disp(ctx) ?: return emptyList()
        return try {
            val m = d.mode
            d.supportedModes
                .filter { it.physicalWidth == m.physicalWidth && it.physicalHeight == m.physicalHeight }
                .map { Math.round(it.refreshRate) }.distinct().sorted()
        } catch (t: Throwable) { rates(ctx) }
    }

    fun maxRate(ctx: Context): Int = ratesAtCurrentRes(ctx).lastOrNull() ?: -1
    fun minRate(ctx: Context): Int = ratesAtCurrentRes(ctx).firstOrNull() ?: -1

    /** e.g. "1080x2400 @ 120 Hz (mode 3)" */
    fun describe(ctx: Context): String {
        val d = disp(ctx) ?: return "UNAVAILABLE"
        return try {
            val m = d.mode
            m.physicalWidth.toString() + "x" + m.physicalHeight + " @ " + Math.round(m.refreshRate) + " Hz (mode " + m.modeId + ")"
        } catch (t: Throwable) { "UNAVAILABLE" }
    }

    /** All modes as text, e.g. "1080x2400: 60/90/120 Hz". */
    fun modesText(ctx: Context): String {
        val d = disp(ctx) ?: return "UNKNOWN"
        return try {
            d.supportedModes.groupBy { it.physicalWidth.toString() + "x" + it.physicalHeight }
                .entries.joinToString("  ") { e ->
                    e.key + ": " + e.value.map { Math.round(it.refreshRate) }.distinct().sorted().joinToString("/") + " Hz"
                }
        } catch (t: Throwable) { "UNKNOWN" }
    }
}
