package com.sanju.systemx.caps

import java.util.concurrent.ConcurrentHashMap

class Capability(
    val name: String,
    val supported: Boolean,
    val controllable: Boolean,
    var verified: Boolean,
    val reason: String,
    val backend: String
)

object Cap {
    const val DISPLAY_HIGH_REFRESH = "DISPLAY_HIGH_REFRESH"
    const val GAME_MODE = "GAME_MODE"
    const val GPU_MONITOR = "GPU_MONITOR"
    const val GPU_PERFORMANCE = "GPU_PERFORMANCE"
    const val CPU_MONITOR = "CPU_MONITOR"
    const val CPU_PERFORMANCE = "CPU_PERFORMANCE"
    const val THERMAL = "THERMAL"
    const val TOUCH_RESPONSE = "TOUCH_RESPONSE"
    const val DISPLAY_COLOR = "DISPLAY_COLOR"
    const val DNS = "DNS"
    const val PING = "PING"
    const val FPS_MONITOR = "FPS_MONITOR"
}

/** Central registry filled by Detect and updated at run time (e.g. FPS_MONITOR once frames are seen). */
object Caps {
    private val map = ConcurrentHashMap<String, Capability>()
    fun put(c: Capability) { map[c.name] = c }
    fun get(n: String): Capability? = map[n]
    fun supported(n: String): Boolean = map[n]?.supported == true
    fun controllable(n: String): Boolean = map[n]?.controllable == true
    fun markVerified(n: String) { map[n]?.verified = true }
    fun reason(n: String): String = map[n]?.reason ?: "not detected yet"
    fun all(): List<Capability> = map.values.sortedBy { it.name }
    fun clear() { map.clear() }
}
