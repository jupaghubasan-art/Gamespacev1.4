package com.sanju.systemx.optimizer

import com.sanju.systemx.caps.Cap
import com.sanju.systemx.caps.Caps
import com.sanju.systemx.device.Detect
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.CommandResult
import com.sanju.systemx.shizuku.ShizukuBridge

class GpuResult(val step: Step, val floorMhz: Int)

/**
 * Every privileged change goes through here. Rules for each step:
 * 1. Save the original value to the restore journal BEFORE changing anything.
 * 2. Apply through a legitimate Android / vendor interface.
 * 3. Read back where Android allows it. VERIFIED is only returned when a read-back proved it.
 * 4. Report FAILED / UNSUPPORTED honestly. Never report success from an exit code alone.
 */
object Applier {
    val EFFECTS = listOf("COOL", "VIVID", "CINEMATIC", "PERFORMANCE", "DEFAULT")
    val DNS_NAMES = listOf("AUTO", "CLOUDFLARE", "GOOGLE", "QUAD9")
    private val DNS_HOSTS = listOf("", "one.one.one.one", "dns.google", "dns.quad9.net")
    val TOUCH_NAMES = listOf("FAST", "DEFAULT", "SLOW")
    val GPU_LEVELS = listOf("BALANCED", "PERFORMANCE", "MAXIMUM BEST-EFFORT")

    private const val JOURNAL = "journal"
    private val BAD = listOf("error", "usage", "unknown", "exception", "invalid", "not found", "denied", "unsupported")

    // ------------------------------------------------------------------ journal
    private fun load(prefs: Prefs): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        for (l in prefs.getS(JOURNAL, "").lines()) {
            val i = l.indexOf('=')
            if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
        }
        return m
    }

    private fun save(prefs: Prefs, m: Map<String, String>) {
        prefs.setSNow(JOURNAL, m.entries.joinToString("\n") { it.key + "=" + it.value })
    }

    fun hasJournal(prefs: Prefs): Boolean = load(prefs).isNotEmpty()

    private fun saveOnce(prefs: Prefs, key: String, value: String) {
        val m = load(prefs)
        if (!m.containsKey(key)) { m[key] = value; save(prefs, m) }
    }

    // ------------------------------------------------------------------ helpers
    private fun okCmd(r: CommandResult): Boolean = r.ok && BAD.none { r.out.contains(it, true) }
    private fun okSf(r: CommandResult): Boolean = r.ok && r.out.contains("Parcel(") && !r.out.contains("rror", true)

    private fun same(a: String, b: String): Boolean {
        if (a == b) return true
        val x = a.toFloatOrNull()
        val y = b.toFloatOrNull()
        return x != null && y != null && x == y
    }

    /** Saves the original, writes the value, reads it back. True only when the read-back matches. */
    private fun putSetting(prefs: Prefs, ns: String, key: String, value: String): Boolean {
        saveOnce(prefs, "set:$ns:$key", ShizukuBridge.setting(ns, key))
        val r = ShizukuBridge.sh("settings put $ns $key $value", 3000L, "SETTINGS")
        if (!r.ok) return false
        return same(ShizukuBridge.setting(ns, key), value)
    }

    private fun restoreSetting(ns: String, key: String, v: String): Boolean {
        val cmd = if (v == "null") "settings delete $ns $key" else "settings put $ns $key $v"
        val r = ShizukuBridge.sh(cmd, 3000L, "SETTINGS")
        return r.ok && same(ShizukuBridge.setting(ns, key), v)
    }

    // ------------------------------------------------------------------ DISPLAY
    /** Requests the refresh rate through the standard AOSP keys (plus MIUI's key if that device has it). */
    fun applyDisplay(prefs: Prefs, reqHz: Int): Step {
        if (reqHz <= 0 || !Caps.controllable(Cap.DISPLAY_HIGH_REFRESH)) return Step(St.UNSUPPORTED, Caps.reason(Cap.DISPLAY_HIGH_REFRESH))
        val v = "$reqHz.0"
        val a = putSetting(prefs, "system", "min_refresh_rate", v)
        val b = putSetting(prefs, "system", "peak_refresh_rate", v)
        if (ShizukuBridge.setting("system", "user_refresh_rate") != "null") putSetting(prefs, "system", "user_refresh_rate", reqHz.toString())
        return if (a || b) Step(St.REQUESTED, "$reqHz Hz requested, checking the real panel...")
        else Step(St.FAILED, "system refused the refresh-rate setting")
    }

    // ------------------------------------------------------------------ GAME MODE
    fun applyGameMode(prefs: Prefs, pkg: String, fps: Int): Step {
        if (!Caps.controllable(Cap.GAME_MODE)) return Step(St.UNSUPPORTED, Caps.reason(Cap.GAME_MODE))
        saveOnce(prefs, "game.mode:$pkg", "standard")
        var withFps = fps > 0
        var r = ShizukuBridge.sh("cmd game set --mode performance " + (if (withFps) "--fps $fps " else "") + pkg + " 2>&1", 4000L, "GAME_MODE")
        if (!okCmd(r) && withFps) {
            withFps = false
            r = ShizukuBridge.sh("cmd game set --mode performance $pkg 2>&1", 4000L, "GAME_MODE")
        }
        if (!okCmd(r)) r = ShizukuBridge.sh("cmd game mode performance $pkg 2>&1", 4000L, "GAME_MODE")
        return if (okCmd(r)) Step(St.APPLIED, "performance" + (if (withFps) ", $fps FPS hint" else "") + " accepted. Android has no read-back, check the FPS monitor")
        else Step(St.FAILED, r.out.take(70).ifEmpty { "rejected" })
    }

    private fun restoreGameMode(pkg: String): Boolean {
        var r = ShizukuBridge.sh("cmd game set --mode standard $pkg 2>&1", 4000L, "GAME_MODE")
        if (!okCmd(r)) r = ShizukuBridge.sh("cmd game mode standard $pkg 2>&1", 4000L, "GAME_MODE")
        ShizukuBridge.sh("cmd game reset $pkg 2>&1", 4000L, "GAME_MODE")
        return okCmd(r)
    }

    // ------------------------------------------------------------------ CPU
    fun applyCpu(prefs: Prefs): Step {
        if (!Caps.controllable(Cap.CPU_PERFORMANCE)) return Step(St.UNSUPPORTED, Caps.reason(Cap.CPU_PERFORMANCE))
        saveOnce(prefs, "cpu.fixed", "false")
        val r = ShizukuBridge.sh("cmd power set-fixed-performance-mode-enabled true 2>&1", 4000L, "CPU_PERFORMANCE")
        if (!okCmd(r)) return Step(St.FAILED, r.out.take(70).ifEmpty { "rejected" })
        val g = ShizukuBridge.sh("cmd power get-fixed-performance-mode-enabled 2>&1", 3000L, "CPU_PERFORMANCE")
        return if (g.ok && g.out.contains("true", true)) { Caps.markVerified(Cap.CPU_PERFORMANCE); Step(St.VERIFIED, "fixed performance mode on (effect depends on the device)") }
        else Step(St.APPLIED, "fixed performance mode accepted (no read-back)")
    }

    fun releaseCpu(prefs: Prefs): List<String> = restoreKeys(prefs) { it == "cpu.fixed" }

    // ------------------------------------------------------------------ GPU
    /** Picks a REAL frequency step the kernel lists. Nothing is hard-coded. level: 0 balanced, 1 performance, 2 maximum. */
    fun pickGpu(g: Sampler.GpuInfo, level: Int): Long? {
        val cap = if (g.maxF > 0) g.maxF else (g.avail.lastOrNull() ?: return null)
        val steps = g.avail.filter { it <= cap }.sorted()
        if (steps.isEmpty()) return null
        return when (level) {
            0 -> steps[steps.size / 2]
            1 -> steps[((steps.size * 3) / 4).coerceAtMost(steps.size - 1)]
            else -> steps[steps.size - 1]
        }
    }

    fun applyGpu(prefs: Prefs, g: Sampler.GpuInfo?, level: Int): GpuResult {
        if (g == null || !Caps.controllable(Cap.GPU_PERFORMANCE) || !g.writableMin) {
            return GpuResult(Step(St.UNSUPPORTED, Caps.reason(Cap.GPU_PERFORMANCE)), -1)
        }
        val pick = pickGpu(g, level) ?: return GpuResult(Step(St.FAILED, "no usable frequency step"), -1)
        saveOnce(prefs, "gpu.min", g.dir + "|" + g.minF)
        val w = ShizukuBridge.sh("echo $pick > ${g.dir}/min_freq", 3000L, "GPU_PERFORMANCE")
        val now = ShizukuBridge.sh("cat ${g.dir}/min_freq", 3000L, "GPU_PERFORMANCE").stdout.trim().toLongOrNull()
        val mhz = Sampler.rawToMhz(pick)
        return if (now == pick) GpuResult(Step(St.APPLIED, GPU_LEVELS[level.coerceIn(0, 2)] + ": floor " + mhz + " MHz written, waiting for the clock"), mhz)
        else GpuResult(Step(St.FAILED, "kernel refused the write" + (if (w.stderr.isNotEmpty()) " (" + w.stderr.take(40) + ")" else "")), -1)
    }

    fun releaseGpu(prefs: Prefs): List<String> = restoreKeys(prefs) { it == "gpu.min" }

    // ------------------------------------------------------------------ EFFECTS
    private fun sfMatrix(r: Float, g: Float, b: Float): String =
        "service call SurfaceFlinger 1015 i32 1 f $r f 0 f 0 f 0 f 0 f $g f 0 f 0 f 0 f 0 f $b f 0 f 0 f 0 f 0 f 1"

    /** fx: 0 COOL, 1 VIVID, 2 CINEMATIC, 3 PERFORMANCE, 4 DEFAULT. These change the DISPLAY pipeline, not the game's engine. */
    fun applyFx(prefs: Prefs, fx: Int): Step {
        if (fx >= 3) {
            restoreKeys(prefs) { it == "fx.sf" || it == "set:secure:display_color_mode" }
            return Step(St.APPLIED, if (fx == 4) "default colours" else "no colour processing")
        }
        if (!Caps.controllable(Cap.DISPLAY_COLOR)) return Step(St.UNSUPPORTED, Caps.reason(Cap.DISPLAY_COLOR))
        var verified = false
        var detail = ""
        if (fx != 0 && Detect.colorModeOk) {
            val mode = if (fx == 1) "1" else "0"
            if (putSetting(prefs, "secure", "display_color_mode", mode)) { verified = true; detail = "colour mode $mode" }
        }
        var sfDone = false
        if (Detect.sfColorOk) {
            val sat: Float
            val matrix: String
            when (fx) {
                0 -> { sat = 1.0f; matrix = sfMatrix(0.93f, 0.98f, 1.06f) }
                1 -> { sat = 1.4f; matrix = "service call SurfaceFlinger 1015 i32 0" }
                else -> { sat = 0.9f; matrix = sfMatrix(1.04f, 0.98f, 0.90f) }
            }
            saveOnce(prefs, "fx.sf", "1")
            val a = ShizukuBridge.sh("service call SurfaceFlinger 1022 f $sat 2>&1", 3000L, "DISPLAY_COLOR")
            val b = ShizukuBridge.sh("$matrix 2>&1", 3000L, "DISPLAY_COLOR")
            sfDone = okSf(a) && okSf(b)
        }
        return when {
            verified -> { Caps.markVerified(Cap.DISPLAY_COLOR); Step(St.VERIFIED, detail + (if (sfDone) " + colour transform" else "")) }
            sfDone -> Step(St.APPLIED, "SurfaceFlinger colour transform (Android gives no read-back)")
            else -> Step(St.FAILED, "this device rejected the colour change")
        }
    }

    // ------------------------------------------------------------------ TOUCH
    /** level: 0 FAST, 1 DEFAULT, 2 SLOW. Uses Android's touch-and-hold delay. It does NOT change raw touch latency. */
    fun applyTouch(prefs: Prefs, level: Int): Step {
        if (!Caps.controllable(Cap.TOUCH_RESPONSE)) return Step(St.UNSUPPORTED, Caps.reason(Cap.TOUCH_RESPONSE))
        if (level == 1) {
            val l = restoreKeys(prefs) { it == "set:secure:long_press_timeout" }
            return Step(St.APPLIED, if (l.isEmpty()) "system default" else "system default restored")
        }
        val ms = if (level == 0) 250 else 700
        return if (putSetting(prefs, "secure", "long_press_timeout", ms.toString())) {
            Caps.markVerified(Cap.TOUCH_RESPONSE)
            Step(St.VERIFIED, "touch-and-hold delay $ms ms (Android has no touch-latency control)")
        } else Step(St.FAILED, "system refused the setting")
    }

    // ------------------------------------------------------------------ DNS
    /** idx: 0 AUTO (system), 1 CLOUDFLARE, 2 GOOGLE, 3 QUAD9. DNS affects name lookups, not in-match ping. */
    fun applyDns(prefs: Prefs, idx: Int): Step {
        if (!Caps.controllable(Cap.DNS)) return Step(St.UNSUPPORTED, Caps.reason(Cap.DNS))
        if (idx <= 0) {
            val l = restoreKeys(prefs) { it == "set:global:private_dns_mode" || it == "set:global:private_dns_specifier" }
            return Step(St.APPLIED, if (l.isEmpty()) "system DNS" else "system DNS restored")
        }
        val host = DNS_HOSTS[idx.coerceIn(1, 3)]
        val a = putSetting(prefs, "global", "private_dns_specifier", host)
        val b = putSetting(prefs, "global", "private_dns_mode", "hostname")
        return if (a && b) { Caps.markVerified(Cap.DNS); Step(St.VERIFIED, "Private DNS $host (setting read back)") }
        else Step(St.FAILED, "system refused Private DNS")
    }

    // ------------------------------------------------------------------ BACKGROUND
    private val KEEP_WORDS = listOf("whatsapp", "telegram", "messenger", "signal", "discord", "spotify", "music", "maps", "waze", "authenticator", "banking", "shizuku")

    /** Asks Android to stop only safe background processes of user apps. Never force-stops and never touches system apps. */
    fun applyBackground(prefs: Prefs, gamePkg: String, selfPkg: String): Step {
        val third = ShizukuBridge.sh("pm list packages -3 2>/dev/null", 6000L, "BACKGROUND").stdout.lines()
            .filter { it.startsWith("package:") }.map { it.removePrefix("package:").trim() }
        if (third.isEmpty()) return Step(St.UNSUPPORTED, "cannot list user apps")
        val keep = HashSet<String>()
        keep.add(gamePkg); keep.add(selfPkg); keep.add(ShizukuBridge.PKG)
        for (g in com.sanju.systemx.game.ProfileStore.all()) keep.add(g.pkg)
        keep.addAll(prefs.getS("bg_whitelist", "").split(',').map { it.trim() }.filter { it.isNotEmpty() })
        val ime = ShizukuBridge.setting("secure", "default_input_method").substringBefore('/')
        keep.add(ime)
        ShizukuBridge.setting("secure", "enabled_accessibility_services").split(':').forEach { keep.add(it.substringBefore('/')) }
        keep.add(ShizukuBridge.setting("secure", "sms_default_application"))
        val home = ShizukuBridge.sh("cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null", 4000L, "BACKGROUND")
            .stdout.lines().lastOrNull { it.contains('/') }?.trim()?.substringBefore('/')
        if (home != null) keep.add(home)
        fun running(): Set<String> {
            val names = ShizukuBridge.sh("ps -A -o NAME 2>/dev/null", 6000L, "BACKGROUND").stdout.lines().map { it.trim() }.filter { it.isNotEmpty() }
            return third.filter { p -> names.any { it == p || it.startsWith("$p:") } }.toSet()
        }
        val before = running()
        val targets = before.filter { p ->
            p !in keep && Regex("^[A-Za-z0-9._]+$").matches(p) && KEEP_WORDS.none { p.contains(it, true) }
        }.take(30)
        if (targets.isEmpty()) return Step(St.APPLIED, "nothing safe to stop")
        ShizukuBridge.sh(targets.joinToString("; ") { "am kill $it" }, 15000L, "BACKGROUND")
        val after = running()
        val stopped = targets.count { it !in after }
        return if (stopped > 0) Step(St.VERIFIED, "$stopped of ${targets.size} background apps stopped (they restart on demand)")
        else Step(St.APPLIED, "asked ${targets.size} apps to stop, Android kept them")
    }

    // ------------------------------------------------------------------ restore
    fun restore(prefs: Prefs): List<String> {
        val l = restoreKeys(prefs) { true }
        return if (l.isEmpty()) listOf("NOTHING TO RESTORE") else l
    }

    /** Restores every journal entry whose key matches. Entries that fail stay in the journal and are retried later. */
    fun restoreKeys(prefs: Prefs, match: (String) -> Boolean): List<String> {
        val j = load(prefs)
        val lines = ArrayList<String>()
        val remaining = LinkedHashMap<String, String>()
        for ((k, v) in j) {
            if (!match(k)) { remaining[k] = v; continue }
            val ok = when {
                k.startsWith("set:") -> {
                    val p = k.split(":", limit = 3)
                    p.size == 3 && restoreSetting(p[1], p[2], v)
                }
                k.startsWith("game.mode:") -> restoreGameMode(k.substringAfter(':'))
                k == "game.mode" -> restoreGameMode(com.sanju.systemx.game.ProfileStore.MLBB)
                k == "sys.min_refresh_rate" -> restoreSetting("system", "min_refresh_rate", v)
                k == "sys.peak_refresh_rate" -> restoreSetting("system", "peak_refresh_rate", v)
                k == "gpu.min" -> {
                    val p = v.split('|')
                    p.size == 2 && (p[1].toLongOrNull() ?: 0L) > 0L &&
                        ShizukuBridge.sh("echo ${p[1]} > ${p[0]}/min_freq", 3000L, "GPU_PERFORMANCE").ok
                }
                k == "cpu.fixed" -> ShizukuBridge.sh("cmd power set-fixed-performance-mode-enabled false 2>&1", 4000L, "CPU_PERFORMANCE").ok
                k == "fx.sf" -> {
                    val a = ShizukuBridge.sh("service call SurfaceFlinger 1022 f 1.0 2>&1", 3000L, "DISPLAY_COLOR")
                    val b = ShizukuBridge.sh("service call SurfaceFlinger 1015 i32 0 2>&1", 3000L, "DISPLAY_COLOR")
                    okSf(a) && okSf(b)
                }
                else -> true
            }
            if (ok) lines.add("RESTORED $k") else { remaining[k] = v; lines.add("RESTORE FAILED $k (will retry)") }
        }
        save(prefs, remaining)
        return lines
    }
}
