package com.sanju.systemx.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.sanju.systemx.sfx.Sfx
import com.sanju.systemx.sfx.SfxHub

object Pal {
    val BG = Color.parseColor("#050507")
    val PANEL = Color.parseColor("#0E0E12")
    val PANEL2 = Color.parseColor("#1A1A21")
    val RED = Color.parseColor("#E5173F")
    val RED_DIM = Color.parseColor("#5A0F1E")
    val TEXT = Color.WHITE
    val SUB = Color.parseColor("#9A9AA6")
    val GREEN = Color.parseColor("#2ECC71")
    val AMBER = Color.parseColor("#F5A623")
    @Volatile var haptic = true
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

val HUD_FONT: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)

fun Context.tv(text: String, sp: Float = 13f, color: Int = Pal.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sp
    t.setTextColor(color)
    if (bold) t.typeface = HUD_FONT
    return t
}

fun Context.bg(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.panel(title: String): LinearLayout {
    val p = LinearLayout(this)
    p.orientation = LinearLayout.VERTICAL
    p.background = bg(Pal.PANEL, 10, Pal.RED_DIM, 1)
    p.setPadding(dp(14), dp(10), dp(14), dp(12))
    val t = tv(title, 11f, Pal.RED, true)
    t.letterSpacing = 0.15f
    p.addView(t)
    return p
}

fun LinearLayout.add(v: View, topDp: Int = 0, weight: Float = 0f, w: Int = LinearLayout.LayoutParams.MATCH_PARENT, h: Int = LinearLayout.LayoutParams.WRAP_CONTENT) {
    val lp = if (orientation == LinearLayout.VERTICAL && weight > 0f) LinearLayout.LayoutParams(w, 0, weight)
    else if (orientation == LinearLayout.HORIZONTAL && weight > 0f) LinearLayout.LayoutParams(0, h, weight)
    else LinearLayout.LayoutParams(w, h)
    lp.topMargin = context.dp(topDp)
    addView(v, lp)
}

/** Label on the left, value on the right. */
class Row(ctx: Context, label: String) {
    val view = LinearLayout(ctx)
    private val value = ctx.tv("-", 13f, Pal.TEXT, true)
    init {
        view.orientation = LinearLayout.HORIZONTAL
        val l = ctx.tv(label, 11f, Pal.SUB)
        view.addView(l, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        value.gravity = Gravity.END
        view.addView(value, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }
    fun set(text: String, color: Int = Pal.TEXT) { if (value.text.toString() != text) value.text = text; value.setTextColor(color) }
}

/** Segmented selector: one option highlighted in red. */
class Seg(private val ctx: Context, opts: List<String>, sel: Int, private val onPick: (Int) -> Unit) {
    val view = LinearLayout(ctx)
    private val items = ArrayList<TextView>()
    init {
        view.orientation = LinearLayout.HORIZONTAL
        for ((i, o) in opts.withIndex()) {
            val t = ctx.tv(o, 11f, Pal.SUB, true)
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.dp(4), ctx.dp(10), ctx.dp(4), ctx.dp(10))
            t.setOnClickListener { select(i); onPick(i) }
            items.add(t)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = ctx.dp(4)
            view.addView(t, lp)
        }
        select(sel)
    }
    fun select(sel: Int) {
        for ((i, t) in items.withIndex()) {
            val on = i == sel
            t.background = ctx.bg(if (on) Pal.RED else Pal.PANEL2, 8)
            t.setTextColor(if (on) Pal.TEXT else Pal.SUB)
        }
    }
}

/** ON/OFF row. Plays the toggle sounds. */
class Tog(private val ctx: Context, label: String, on: Boolean, private val onChange: (Boolean) -> Unit) {
    val view = LinearLayout(ctx)
    private val pill = ctx.tv("OFF", 11f, Pal.TEXT, true)
    private var state = on
    init {
        view.orientation = LinearLayout.HORIZONTAL
        view.gravity = Gravity.CENTER_VERTICAL
        view.addView(ctx.tv(label, 12f, Pal.TEXT), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        pill.gravity = Gravity.CENTER
        pill.setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(16), ctx.dp(8))
        view.addView(pill, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        pill.setOnClickListener {
            state = !state
            paint()
            SfxHub.play(if (state) Sfx.TOGGLE_ON else Sfx.TOGGLE_OFF)
            onChange(state)
        }
        paint()
    }
    private fun paint() {
        pill.text = if (state) "ON" else "OFF"
        pill.background = ctx.bg(if (state) Pal.RED else Pal.PANEL2, 8)
    }
}

fun Context.button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
    val t = tv(text, 12f, Pal.TEXT, true)
    t.gravity = Gravity.CENTER
    t.letterSpacing = 0.08f
    t.setPadding(dp(8), dp(12), dp(8), dp(12))
    t.background = bg(if (filled) Pal.RED else Pal.PANEL2, 10, Pal.RED_DIM, 1)
    t.setOnClickListener { SfxHub.play(Sfx.CLICK); onClick() }
    return t
}

/** FPS history. NaN = no data (drawn as a gap, never as a fake value). */
class GraphView(ctx: Context) : View(ctx) {
    private val vals = FloatArray(60) { Float.NaN }
    var target = 90f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint()
    private val tgt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        line.color = Pal.RED; line.style = Paint.Style.STROKE; line.strokeWidth = ctx.dp(2).toFloat()
        grid.color = Pal.PANEL2; grid.strokeWidth = 1f
        tgt.color = Pal.RED_DIM; tgt.style = Paint.Style.STROKE; tgt.strokeWidth = 2f
        tgt.pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }

    fun push(v: Float) {
        System.arraycopy(vals, 1, vals, 0, vals.size - 1)
        vals[vals.size - 1] = if (v < 0f) Float.NaN else v
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        var mx = target * 1.25f
        for (v in vals) if (!v.isNaN() && v > mx) mx = v
        for (i in 1..3) c.drawLine(0f, h * i / 4f, w, h * i / 4f, grid)
        val ty = h - h * (target / mx)
        c.drawLine(0f, ty, w, ty, tgt)
        path.reset()
        var pen = false
        val step = w / (vals.size - 1)
        for (i in vals.indices) {
            val v = vals[i]
            if (v.isNaN()) { pen = false; continue }
            val x = i * step
            val y = h - h * (v / mx)
            if (!pen) { path.moveTo(x, y); pen = true } else path.lineTo(x, y)
        }
        c.drawPath(path, line)
    }
}
