package com.sanju.systemx.settings

import android.content.Context
import android.content.SharedPreferences

class Prefs private constructor(private val sp: SharedPreferences) {
    fun getB(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun setB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun getI(k: String, d: Int): Int = sp.getInt(k, d)
    fun setI(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun getF(k: String, d: Float): Float = sp.getFloat(k, d)
    fun setF(k: String, v: Float) { sp.edit().putFloat(k, v).apply() }
    fun getS(k: String, d: String): String = sp.getString(k, d) ?: d
    fun setS(k: String, v: String) { sp.edit().putString(k, v).apply() }
    /** Synchronous write, used for the restore journal so it survives a crash. */
    fun setSNow(k: String, v: String) { sp.edit().putString(k, v).commit() }

    companion object {
        fun get(ctx: Context): Prefs =
            Prefs(ctx.applicationContext.getSharedPreferences("sanju_systemx_v3", Context.MODE_PRIVATE))
    }
}
