# SanjuSystemX V3 (Game Space)

Shizuku-powered gaming HUD for Mobile Legends (`com.mobile.legends`). Package: `com.sanju.systemx`.

## Build
GitHub: push the files (or this zip) to `main` -> Actions -> *Build SanjuSystemX APK* -> download the artifact.
Local: `gradle assembleDebug assembleRelease` -> `app/build/outputs/apk/debug/app-debug.apk`

## What is real, what is not
| Feature | How | Honest status |
|---|---|---|
| Shizuku status | binder + permission check | CONNECTED / DISCONNECTED / PERMISSION REQUIRED / UNSUPPORTED |
| MLBB detection | shell `dumpsys` foreground check via Shizuku | needs Shizuku; shows "DETECTION UNAVAILABLE" if the OS prints nothing |
| Refresh rate | system `min_refresh_rate` / `peak_refresh_rate` | REQUESTED vs ACTUAL (read from Android) is always shown. Some phones ignore it: shown as NOT APPLIED |
| FPS target 60/90/120 | picks the display rate and is compared with measured FPS | cannot raise a game's internal FPS cap |
| Actual FPS | SurfaceFlinger frame timestamps of the MLBB layer | shows UNAVAILABLE when the device gives no data. Never invented |
| CPU usage/freq/temp | /proc/stat, cpufreq, thermal zones (via Shizuku) | UNAVAILABLE if unreadable |
| GPU usage/freq/temp | read-only vendor files (Adreno kgsl, devfreq) | UNSUPPORTED if not exposed |
| GPU boost / 1200 MHz | writes `min_freq` ONLY if the file is writable and the kernel accepts it | on most phones: UNSUPPORTED ON THIS DEVICE (needs root) |
| Game Mode hint | `cmd game ... performance` (Android 12+) | "accepted by system"; effect depends on the game |
| Touch response | no Android control exists | always UNSUPPORTED |
| Restore | original values saved before changing, restored when MLBB exits | journal also restores after a crash |

## Notes
- Background watcher = foreground service + notification, needed to detect MLBB while the game is in front. After a reboot: start Shizuku, then open SanjuSystemX once.
- Intro: 5 s cinematic, tap to skip. Shizuku/system init starts immediately and does not wait for it.
- Layout: a left rail switches between HOME, PERFORMANCE, GPU / CPU, DISPLAY and SETTINGS pages (`ui/Hud.kt`).
- Eye sound: `res/raw/sfx_eye.wav` is the owner-supplied Itachi intro clip, trimmed to 2.4 s and played at 0.85 s so its peak lands as the eye opens. To use a different clip, replace that file (same name; .wav/.ogg/.mp3 all load by name).
- Sounds are original synthesized tones in `res/raw` (replace by same file name). They use `SoundPool` with no audio focus and never change volume.
- Icon: your Mangekyo image (`res/drawable-nodpi/ic_launcher_fg.png`).


## V3 real-functionality upgrade
- `shizuku/ShizukuBridge.kt`: one privileged execution layer, `CommandResult` (stdout, stderr, exit code, duration, capability, error reason), timeouts, binder received/dead + permission listeners.
- `caps/`, `device/Detect.kt`: capability registry filled from what the device really exposes (display, game mode, GPU, CPU, thermal, touch, colour, DNS, ping, FPS).
- `game/GameProfile.kt`: game profiles (MLBB built in, ADD GAME for others).
- `optimizer/`: `AutoPlan` (60 Hz -> ~30 FPS, 90 -> ~60, 120 -> ~90), `Applier` (apply, read back, journal, restore).
- `net/NetEngine.kt`: real ping / jitter / packet loss.
- `monitor/Sampler.kt`: SurfaceFlinger frame timing, gfxinfo fallback, average / 1% low / frame time / jank, thermal status.
- `ui/Hud.kt`: GAME, PERFORMANCE, DISPLAY, EFFECTS, NETWORK, TOUCH, MONITOR, SETTINGS.
- See `CONTROL_AUDIT.md` for the backend, verification and restore of every control.
- Build: GitHub Actions runs `gradle assembleDebug assembleRelease`. Locally: `gradle :app:assembleDebug` (there is no Gradle wrapper in this repository).
